import { Transaction } from '../types';

export const recentTransactions: Transaction[] = [
  { id: 1, name: 'Netflix Subscription', amount: -15.99, date: '2024-03-15', type: 'expense' },
  { id: 2, name: 'Salary Deposit', amount: 5000.00, date: '2024-03-14', type: 'income' },
  { id: 3, name: 'Amazon Purchase', amount: -124.50, date: '2024-03-13', type: 'expense' },
  { id: 4, name: 'Freelance Payment', amount: 850.00, date: '2024-03-12', type: 'income' },
];