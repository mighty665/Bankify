import React from 'react';
import { 
  Home, 
  CreditCard, 
  PiggyBank, 
  ArrowRightLeft, 
  BarChart3, 
  Settings,
  Wallet,
  HelpCircle,
  Bell
} from 'lucide-react';

const menuItems = [
  { icon: Home, label: 'Dashboard' },
  { icon: Wallet, label: 'Accounts' },
  { icon: ArrowRightLeft, label: 'Transfers' },
  { icon: CreditCard, label: 'Cards' },
  { icon: PiggyBank, label: 'Savings' },
  { icon: BarChart3, label: 'Investments' },
];

const Sidebar = () => {
  return (
    <div className="h-screen w-64 bg-white border-r border-gray-200 flex flex-col">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-blue-600">BankSaaS</h1>
      </div>
      
      <nav className="flex-1 px-4">
        {menuItems.map((item, index) => (
          <button
            key={index}
            className="w-full flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-lg transition-colors mb-1"
          >
            <item.icon className="h-5 w-5" />
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-gray-200">
        <button className="w-full flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-lg transition-colors">
          <Settings className="h-5 w-5" />
          <span className="font-medium">Settings</span>
        </button>
        <button className="w-full flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-lg transition-colors">
          <HelpCircle className="h-5 w-5" />
          <span className="font-medium">Help Center</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;