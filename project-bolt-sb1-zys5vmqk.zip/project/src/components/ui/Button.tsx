import React, { ReactNode } from 'react';

interface ButtonProps {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost';
  className?: string;
  onClick?: () => void;
}

export const Button = ({ 
  children, 
  variant = 'primary',
  className = '',
  onClick 
}: ButtonProps) => {
  const baseStyles = "flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors";
  
  const variantStyles = {
    primary: "bg-blue-600 text-white hover:bg-blue-700",
    secondary: "text-blue-600 hover:bg-blue-50",
    ghost: "text-gray-700 hover:bg-blue-50 hover:text-blue-600"
  };

  return (
    <button 
      className={`${baseStyles} ${variantStyles[variant]} ${className}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
};