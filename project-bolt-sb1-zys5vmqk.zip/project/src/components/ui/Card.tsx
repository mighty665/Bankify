import React, { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
}

export const Card = ({ children, className = '' }: CardProps) => {
  return (
    <div className={`bg-white p-6 rounded-xl shadow-sm ${className}`}>
      {children}
    </div>
  );
};