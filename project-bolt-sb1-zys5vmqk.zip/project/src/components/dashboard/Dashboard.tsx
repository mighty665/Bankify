import React from 'react';
import { 
  CreditCard,
  DollarSign,
  TrendingUp,
  Clock,
  ArrowUpRight
} from 'lucide-react';
import { StatCard } from './StatCard';
import { TransactionList } from './TransactionList';
import { recentTransactions } from '../../data/transactions';

const Dashboard = () => {
  return (
    <div className="flex-1 bg-gray-50 p-6">
      <div className="grid grid-cols-3 gap-6 mb-6">
        <StatCard
          title="Total Balance"
          value="$24,562.00"
          icon={<DollarSign className="h-6 w-6" />}
          trend={{
            value: "+2.5% from last month",
            isPositive: true,
            icon: <TrendingUp className="h-4 w-4" />
          }}
        />

        <StatCard
          title="Monthly Spending"
          value="$4,250.00"
          icon={<CreditCard className="h-6 w-6" />}
          iconColor="text-purple-600"
          trend={{
            value: "+15.3% from last month",
            isPositive: false,
            icon: <ArrowUpRight className="h-4 w-4" />
          }}
        />

        <StatCard
          title="Savings Goal"
          value="$8,400 / $10,000"
          icon={<Clock className="h-6 w-6" />}
          iconColor="text-green-600"
        >
          <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
            <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '84%' }}></div>
          </div>
        </StatCard>
      </div>

      <TransactionList transactions={recentTransactions} />
    </div>
  );
};

export default Dashboard;