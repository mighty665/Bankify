import React, { ReactNode } from 'react';
import { Card } from '../ui/Card';

interface StatCardProps {
  title: string;
  value: string;
  icon: ReactNode;
  trend?: {
    value: string;
    isPositive: boolean;
    icon: ReactNode;
  };
  iconColor?: string;
}

export const StatCard = ({ title, value, icon, trend, iconColor = 'text-blue-600' }: StatCardProps) => {
  return (
    <Card>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-gray-500 text-sm font-medium">{title}</h3>
        <div className={iconColor}>{icon}</div>
      </div>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
      {trend && (
        <p className={`text-sm flex items-center mt-2 ${
          trend.isPositive ? 'text-green-600' : 'text-red-600'
        }`}>
          {trend.icon}
          <span className="ml-1">{trend.value}</span>
        </p>
      )}
    </Card>
  );
};