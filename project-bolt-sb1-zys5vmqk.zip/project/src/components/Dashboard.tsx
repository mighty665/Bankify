import React from 'react';
import { 
  ArrowUpRight, 
  ArrowDownRight,
  CreditCard,
  DollarSign,
  TrendingUp,
  Clock
} from 'lucide-react';

const Dashboard = () => {
  const transactions = [
    { id: 1, name: 'Netflix Subscription', amount: -15.99, date: '2024-03-15', type: 'expense' },
    { id: 2, name: 'Salary Deposit', amount: 5000.00, date: '2024-03-14', type: 'income' },
    { id: 3, name: 'Amazon Purchase', amount: -124.50, date: '2024-03-13', type: 'expense' },
    { id: 4, name: 'Freelance Payment', amount: 850.00, date: '2024-03-12', type: 'income' },
  ];

  return (
    <div className="flex-1 bg-gray-50 p-6">
      <div className="grid grid-cols-3 gap-6 mb-6">
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-500 text-sm font-medium">Total Balance</h3>
            <DollarSign className="h-6 w-6 text-blue-600" />
          </div>
          <p className="text-2xl font-bold text-gray-900">$24,562.00</p>
          <p className="text-sm text-green-600 flex items-center mt-2">
            <TrendingUp className="h-4 w-4 mr-1" />
            +2.5% from last month
          </p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-500 text-sm font-medium">Monthly Spending</h3>
            <CreditCard className="h-6 w-6 text-purple-600" />
          </div>
          <p className="text-2xl font-bold text-gray-900">$4,250.00</p>
          <p className="text-sm text-red-600 flex items-center mt-2">
            <ArrowUpRight className="h-4 w-4 mr-1" />
            +15.3% from last month
          </p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-500 text-sm font-medium">Savings Goal</h3>
            <Clock className="h-6 w-6 text-green-600" />
          </div>
          <p className="text-2xl font-bold text-gray-900">$8,400 / $10,000</p>
          <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
            <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '84%' }}></div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900">Recent Transactions</h2>
          <button className="text-blue-600 text-sm font-medium hover:text-blue-700">
            View All
          </button>
        </div>

        <div className="space-y-4">
          {transactions.map((transaction) => (
            <div key={transaction.id} className="flex items-center justify-between p-4 hover:bg-gray-50 rounded-lg transition-colors">
              <div className="flex items-center space-x-4">
                <div className={`p-2 rounded-lg ${
                  transaction.type === 'income' ? 'bg-green-100' : 'bg-red-100'
                }`}>
                  {transaction.type === 'income' ? (
                    <ArrowDownRight className={`h-6 w-6 ${
                      transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                    }`} />
                  ) : (
                    <ArrowUpRight className={`h-6 w-6 ${
                      transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                    }`} />
                  )}
                </div>
                <div>
                  <p className="font-medium text-gray-900">{transaction.name}</p>
                  <p className="text-sm text-gray-500">{transaction.date}</p>
                </div>
              </div>
              <p className={`font-medium ${
                transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
              }`}>
                {transaction.type === 'income' ? '+' : '-'}${Math.abs(transaction.amount).toFixed(2)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;