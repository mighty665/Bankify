import React from 'react';
import { 
  Home, 
  CreditCard, 
  PiggyBank, 
  ArrowRightLeft, 
  BarChart3, 
  Settings,
  Wallet,
  HelpCircle
} from 'lucide-react';
import { Button } from '../ui/Button';

const menuItems = [
  { icon: Home, label: 'Dashboard' },
  { icon: Wallet, label: 'Accounts' },
  { icon: ArrowRightLeft, label: 'Transfers' },
  { icon: CreditCard, label: 'Cards' },
  { icon: PiggyBank, label: 'Savings' },
  { icon: BarChart3, label: 'Investments' },
];

const Sidebar = () => {
  return (
    <div className="h-screen w-64 bg-white border-r border-gray-200 flex flex-col">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-blue-600">Bankify</h1>
      </div>
      
      <nav className="flex-1 px-4">
        {menuItems.map((item, index) => (
          <Button
            key={index}
            variant="ghost"
            className="w-full mb-1"
          >
            <item.icon className="h-5 w-5" />
            <span className="font-medium">{item.label}</span>
          </Button>
        ))}
      </nav>

      <div className="p-4 border-t border-gray-200">
        <Button variant="ghost" className="w-full">
          <Settings className="h-5 w-5" />
          <span className="font-medium">Settings</span>
        </Button>
        <Button variant="ghost" className="w-full">
          <HelpCircle className="h-5 w-5" />
          <span className="font-medium">Help Center</span>
        </Button>
      </div>
    </div>
  );
};

export default Sidebar;